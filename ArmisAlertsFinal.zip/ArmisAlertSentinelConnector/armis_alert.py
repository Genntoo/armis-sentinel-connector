"""Armis alert collector.

Fetches alerts from Armis via cursor pagination, ingests them into Sentinel and
stores the collected activity UUIDs for asynchronous processing.

Duplicate protection is based on a persisted watermark over the alert update
time plus a tie-breaker set of alert IDs sitting exactly on the watermark, so a
completed pagination cycle never re-ingests history.

Note on exceptions: ArmisException, ArmisDataNotFoundException and
ArmisTimeOutException all derive directly from Exception and are siblings, not
a hierarchy. A bare `except ArmisException` therefore does NOT catch the other
two, and any broad `except Exception` WILL swallow them. Every broad handler in
this module re-raises the siblings explicitly before catching Exception.
"""

import hashlib
import logging
import time
import inspect
from datetime import datetime

from SharedCode.exports_store import ExportsTableStore
from SharedCode.sentinel import send_data_to_sentinel, get_sentinel_client
from SharedCode.utils import Utils
from SharedCode import consts
from SharedCode.armis_exceptions import (
    ArmisException,
    ArmisDataNotFoundException,
    ArmisTimeOutException,
)

CHECKPOINT_PARTITION = "armisalert"
CHECKPOINT_ROW = "alertcheckpoint"
ACTIVITY_PARTITION = "activityuuids"
# Tracks which activity UUIDs of each alert have already been dispatched to
# the Activity function, so an alert update does not re-dispatch its whole
# history of activities. It lives in the CHECKPOINT table, never in the activity
# UUIDs table: the Activity function consumes and deletes everything it finds
# there, which would wipe this state on every run.
ALERT_STATE_PARTITION = "alertactivitystate"

UPDATE_TIME_FIELD = getattr(consts, "ALERT_UPDATE_TIME_FIELD", "lastAlertUpdateTime")
MAX_BOUNDARY_IDS = getattr(consts, "MAX_BOUNDARY_IDS", 500)
# Bound on the per-invocation de-duplication set, to cap memory on a large
# backfill. Roughly 100k short strings.
SEEN_IN_RUN_LIMIT = getattr(consts, "SEEN_IN_RUN_LIMIT", 100000)


def _hash_uuids(uuids):
    """Return a stable fingerprint for an ordered list of activity UUIDs."""
    return hashlib.sha256(",".join(uuids).encode("utf-8")).hexdigest()


def _normalize_cursor(value):
    """Return None for every representation of an absent cursor."""
    if value in (None, "", "None", "null"):
        return None
    return value


def _to_comparable(value):
    """Convert an Armis update-time value into something orderable.

    Handles epoch seconds, epoch milliseconds and ISO-8601 strings. Returns
    None when the value cannot be interpreted, in which case the caller must
    not filter on it.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value) / 1000.0 if value > 1e11 else float(value)
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            numeric = float(text)
            return numeric / 1000.0 if numeric > 1e11 else numeric
        except ValueError:
            pass
        try:
            return datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp()
        except ValueError:
            return None
    return None


class ArmisAlert(Utils):
    """Collects Armis alerts and drives their ingestion into Sentinel."""

    def __init__(self, start_time):
        """Initialize the ArmisAlert object.

        Args:
            start_time (float): value of time.monotonic() captured by the caller
                when the function invocation began.
        """
        super().__init__(log_format=consts.ALERT_LOG_FORMAT)
        self.start_time = start_time
        self.total_alerts_posted = 0
        self.total_alerts_skipped = 0
        self.total_activity_uuids_skipped = 0
        # Committed watermark: everything at or below it has been ingested by
        # a COMPLETED scan. Only this one is used for filtering.
        self.watermark = None
        self.boundary_ids = set()
        # Highest update time seen during the scan in progress. Promoted to the
        # committed watermark only when the scan reaches the end. Advancing the
        # filter mid-scan would be wrong whenever Armis orders newest-first:
        # page 1 would raise the bar and every older page after it would be
        # silently discarded.
        self.pending_watermark = None
        self.pending_boundary_ids = set()
        self.detected_order = None
        # Alert versions already ingested during THIS invocation. A mutable sort
        # key means the same alert can surface on two pages of one scan; the
        # committed watermark cannot catch that because it does not move until
        # the scan ends. Keyed by id and update time so a genuinely newer
        # version is never suppressed.
        self.seen_in_run = set()
        self._update_field_checked = False
        self.check_environment_var_exist(
            [{"ArmisAlertsTableName": consts.ARMIS_ALERTS_TABLE}]
        )

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _timed_out(self):
        """Return True once the function has consumed its execution budget."""
        return (
            time.monotonic() - self.start_time
            >= consts.FUNCTION_APP_TIMEOUT_SECONDS
        )

    def _build_parameters(self):
        """Build the static query parameters for the alert search endpoint.

        Returns:
            dict: query parameters without the cursor.

        Raises:
            ArmisException: if the configured severity is not recognised.
        """
        __method_name = inspect.currentframe().f_code.co_name
        if consts.SEVERITY not in consts.SEVERITIES:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Configured severity '{}' is not one of {}.".format(
                        consts.SEVERITY, consts.SEVERITIES
                    ),
                )
            )
            raise ArmisException(
                "Invalid severity configured: {}".format(consts.SEVERITY)
            )

        severity_index = consts.SEVERITIES.index(consts.SEVERITY)
        included_severities = ",".join(consts.SEVERITIES[severity_index:])

        fields = list(consts.ALERT_FIELDS)
        if UPDATE_TIME_FIELD not in fields:
            fields.append(UPDATE_TIME_FIELD)
            logging.warning(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "'{}' was missing from consts.ALERT_FIELDS and has been "
                    "added at runtime. Add it permanently to ALERT_FIELDS.".format(
                        UPDATE_TIME_FIELD
                    ),
                )
            )

        return {
            "aql": "in:alerts severity:{}".format(included_severities),
            "orderBy": UPDATE_TIME_FIELD,
            "fields": ",".join(fields),
            "length": consts.ALERTS_CHUNK,
        }

    def _detect_order(self, alerts):
        """Log whether Armis is returning this page oldest-first or newest-first.

        Purely diagnostic: the watermark logic below is correct either way. The
        direction only decides whether the early-stop optimisation can be turned
        on, so it is reported rather than acted upon.

        Args:
            alerts (list): alert records for a page.
        """
        __method_name = inspect.currentframe().f_code.co_name
        if self.detected_order is not None or len(alerts) < 2:
            return
        first = _to_comparable(alerts[0].get(UPDATE_TIME_FIELD))
        last = _to_comparable(alerts[-1].get(UPDATE_TIME_FIELD))
        if first is None or last is None or first == last:
            return
        self.detected_order = "desc" if first > last else "asc"
        logging.info(
            consts.ALERT_LOG_FORMAT.format(
                __method_name,
                "Armis is returning alerts {}ending by {} ({}-first). Set "
                "consts.ALERT_SCAN_ORDER to '{}' to enable the early-stop "
                "optimisation.".format(
                    "desc" if self.detected_order == "desc" else "asc",
                    UPDATE_TIME_FIELD,
                    "newest" if self.detected_order == "desc" else "oldest",
                    self.detected_order,
                ),
            )
        )

    def _verify_update_field(self, alerts):
        """Warn loudly if the watermark field is absent from the API response.

        Without this field de-duplication degrades silently into a full
        re-ingestion on every cycle, which is exactly the failure mode this
        module exists to prevent.

        Args:
            alerts (list): alert records from the first non-empty page.
        """
        __method_name = inspect.currentframe().f_code.co_name
        if self._update_field_checked or not alerts:
            return
        self._update_field_checked = True
        present = sum(
            1 for alert in alerts if _to_comparable(alert.get(UPDATE_TIME_FIELD))
        )
        if present == 0:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "None of the returned alerts carry a usable '{}'. "
                    "De-duplication is DISABLED and alerts will be re-ingested "
                    "on every cycle. Check that the field name is correct for "
                    "this Armis version and that it is in ALERT_FIELDS.".format(
                        UPDATE_TIME_FIELD
                    ),
                )
            )
        elif present < len(alerts):
            logging.warning(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Only {}/{} alerts carry a usable '{}'. The rest cannot be "
                    "de-duplicated.".format(present, len(alerts), UPDATE_TIME_FIELD),
                )
            )

    # ------------------------------------------------------------------
    # API access
    # ------------------------------------------------------------------

    def get_alert_data(self, parameter):
        """Fetch one page of alert data from the Armis API.

        An empty page is a normal terminal condition and is returned as such
        rather than raised, so that the caller can still advance the checkpoint.

        Args:
            parameter (dict): query parameters including aql, length and
                optionally cursor.

        Returns:
            tuple: (list of alerts, next_cursor, count_in_page)

        Raises:
            ArmisException: if the response cannot be parsed.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            results = self.make_rest_call(
                method="GET",
                url=consts.URL + consts.SEARCH_SUFFIX,
                params=parameter,
                headers=self.header,
                retry_401=consts.RETRY_COUNT_401,
                retry_429=consts.RETRY_COUNT_429,
            )
        except ArmisException:
            raise
        except Exception as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Failed to fetch alerts from Armis API: {}.".format(err),
                )
            )
            raise ArmisException("Armis API call failed") from err

        data_block = results.get("data") if isinstance(results, dict) else None
        if not isinstance(data_block, dict):
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "API response has no 'data' object. Cannot parse alert page.",
                )
            )
            raise ArmisException("Malformed Armis response: missing 'data'")

        missing = [key for key in ("results", "count") if key not in data_block]
        if missing:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "API response missing expected keys {}. Cannot parse alert "
                    "page.".format(missing),
                )
            )
            raise ArmisException(
                "Malformed Armis response: missing {}".format(missing)
            )

        data = data_block.get("results") or []
        count_per_page = data_block.get("count") or 0
        next_cursor = _normalize_cursor(data_block.get("nextCursor"))

        for alert in data:
            alert["armis_alert_time"] = alert.get("time")
            alert["alert_type"] = alert.get("type")
            alert["alert_title"] = alert.get("title")

        self._verify_update_field(data)
        self._detect_order(data)
        return data, next_cursor, count_per_page

    # ------------------------------------------------------------------
    # de-duplication
    # ------------------------------------------------------------------

    def _already_seen_in_run(self, alert, updated_at):
        """Return True if this exact alert version was ingested earlier in the run.

        Args:
            alert (dict): alert record.
            updated_at: parsed update time, or None.

        Returns:
            bool
        """
        __method_name = inspect.currentframe().f_code.co_name
        alert_id = str(alert.get("alertId", "")).strip()
        if not alert_id:
            return False
        key = "{}|{}".format(alert_id, updated_at)
        if key in self.seen_in_run:
            return True
        if len(self.seen_in_run) >= SEEN_IN_RUN_LIMIT:
            if len(self.seen_in_run) == SEEN_IN_RUN_LIMIT:
                logging.warning(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "In-run de-duplication set reached {} entries and is no "
                        "longer growing, to bound memory. Alerts reordered by "
                        "Armis mid-scan may produce a duplicate row from here "
                        "on.".format(SEEN_IN_RUN_LIMIT),
                    )
                )
                self.seen_in_run.add("__limit_logged__")
            return False
        self.seen_in_run.add(key)
        return False

    def _filter_already_ingested(self, alerts):
        """Drop alerts that this connector has already sent to Sentinel.

        An alert is considered already ingested when its update time is older
        than the watermark, or equal to the watermark and its ID is in the
        boundary set. Alerts with an unparseable update time are kept, since
        dropping them could lose data.

        Args:
            alerts (list): alert records for the current page.

        Returns:
            list: alerts that still need to be ingested.
        """
        __method_name = inspect.currentframe().f_code.co_name
        if self.watermark is None:
            return [
                alert
                for alert in alerts
                if not self._already_seen_in_run(
                    alert, _to_comparable(alert.get(UPDATE_TIME_FIELD))
                )
            ]

        fresh = []
        for alert in alerts:
            updated_at = _to_comparable(alert.get(UPDATE_TIME_FIELD))
            if self._already_seen_in_run(alert, updated_at):
                continue
            if updated_at is None:
                fresh.append(alert)
                continue
            if updated_at < self.watermark:
                continue
            if (
                updated_at == self.watermark
                and str(alert.get("alertId", "")) in self.boundary_ids
            ):
                continue
            fresh.append(alert)

        skipped = len(alerts) - len(fresh)
        if skipped:
            self.total_alerts_skipped += skipped
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Skipped {} alerts already ingested (watermark {}).".format(
                        skipped, self.watermark
                    ),
                )
            )
        return fresh

    def _track_pending_watermark(self, alerts):
        """Record the highest update time seen so far in the scan in progress.

        Nothing here affects filtering. The value only becomes the filtering
        watermark once the scan completes, via _promote_watermark.

        Args:
            alerts (list): alerts successfully sent to Sentinel.
        """
        __method_name = inspect.currentframe().f_code.co_name
        highest = self.pending_watermark
        for alert in alerts:
            updated_at = _to_comparable(alert.get(UPDATE_TIME_FIELD))
            if updated_at is None:
                continue
            if highest is None or updated_at > highest:
                highest = updated_at

        if highest is None:
            return

        if highest != self.pending_watermark:
            self.pending_watermark = highest
            self.pending_boundary_ids = set()

        for alert in alerts:
            if _to_comparable(alert.get(UPDATE_TIME_FIELD)) == self.pending_watermark:
                alert_id = str(alert.get("alertId", "")).strip()
                if alert_id:
                    self.pending_boundary_ids.add(alert_id)

        if len(self.pending_boundary_ids) > MAX_BOUNDARY_IDS:
            logging.warning(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "More than {} alerts share the pending watermark timestamp; "
                    "truncating the tie-breaker set, some alerts may be "
                    "re-ingested.".format(MAX_BOUNDARY_IDS),
                )
            )
            self.pending_boundary_ids = set(
                sorted(self.pending_boundary_ids)[:MAX_BOUNDARY_IDS]
            )

    def _promote_watermark(self):
        """Make the scan's highest update time the new filtering watermark.

        Called only when a scan has reached the end of the pagination, which is
        the point at which every alert at or below that time is known to have
        been seen.
        """
        __method_name = inspect.currentframe().f_code.co_name
        if self.pending_watermark is None:
            return

        if self.watermark is None or self.pending_watermark > self.watermark:
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Scan complete. Watermark {} -> {}.".format(
                        self.watermark, self.pending_watermark
                    ),
                )
            )
            self.watermark = self.pending_watermark
            self.boundary_ids = set(self.pending_boundary_ids)
        elif self.pending_watermark == self.watermark:
            # Same timestamp, but alerts sharing it were ingested this scan.
            # Merging the tie-breaker sets is what stops them coming back.
            merged = self.boundary_ids | self.pending_boundary_ids
            if len(merged) > MAX_BOUNDARY_IDS:
                logging.warning(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "Tie-breaker set exceeds {} entries; truncating. Some "
                        "alerts sharing the watermark may be "
                        "re-ingested.".format(MAX_BOUNDARY_IDS),
                    )
                )
                merged = set(sorted(merged)[:MAX_BOUNDARY_IDS])
            self.boundary_ids = merged

        self.pending_watermark = None
        self.pending_boundary_ids = set()

    # ------------------------------------------------------------------
    # persistence
    # ------------------------------------------------------------------

    def _save_checkpoint(self, checkpoint_table: ExportsTableStore, cursor):
        """Persist cursor and watermark state.

        Azure Table MERGE never removes properties, so absent values are stored
        as empty strings rather than None.

        Args:
            checkpoint_table (ExportsTableStore): checkpoint table.
            cursor: cursor to resume from on the next page, or None to restart
                the scan from the beginning of the ordering.
        """
        __method_name = inspect.currentframe().f_code.co_name
        payload = {
            "cursor": "" if cursor is None else str(cursor),
            "watermark": "" if self.watermark is None else repr(self.watermark),
            "boundary_ids": ",".join(sorted(self.boundary_ids)),
            "pending_watermark": (
                "" if self.pending_watermark is None else repr(self.pending_watermark)
            ),
            "pending_boundary_ids": ",".join(sorted(self.pending_boundary_ids)),
        }
        checkpoint_table.merge(CHECKPOINT_PARTITION, CHECKPOINT_ROW, payload)
        logging.info(
            consts.ALERT_LOG_FORMAT.format(
                __method_name,
                "Checkpoint saved. cursor={}, watermark={}, pending={}, "
                "boundary_ids={}.".format(
                    cursor,
                    self.watermark,
                    self.pending_watermark,
                    len(self.boundary_ids),
                ),
            )
        )

    def _load_checkpoint(self, checkpoint_table: ExportsTableStore):
        """Read cursor and watermark state from the checkpoint table.

        Args:
            checkpoint_table (ExportsTableStore): checkpoint table.

        Returns:
            The cursor to resume from, or None to start from the beginning.
        """
        __method_name = inspect.currentframe().f_code.co_name
        record = checkpoint_table.get(CHECKPOINT_PARTITION, CHECKPOINT_ROW)
        if record is None:
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "No checkpoint found. Starting from the beginning.",
                )
            )
            checkpoint_table.post(
                CHECKPOINT_PARTITION,
                CHECKPOINT_ROW,
                {
                    "cursor": "",
                    "watermark": "",
                    "boundary_ids": "",
                    "pending_watermark": "",
                    "pending_boundary_ids": "",
                },
            )
            return None

        cursor = _normalize_cursor(record.get("cursor"))
        self.watermark = _to_comparable(record.get("watermark"))
        raw_ids = record.get("boundary_ids") or ""
        self.boundary_ids = {part for part in raw_ids.split(",") if part}
        self.pending_watermark = _to_comparable(record.get("pending_watermark"))
        raw_pending = record.get("pending_boundary_ids") or ""
        self.pending_boundary_ids = {part for part in raw_pending.split(",") if part}
        logging.info(
            consts.ALERT_LOG_FORMAT.format(
                __method_name,
                "Resuming. cursor={}, watermark={}, pending={}, "
                "boundary_ids={}.".format(
                    cursor,
                    self.watermark,
                    self.pending_watermark,
                    len(self.boundary_ids),
                ),
            )
        )
        return cursor

    @staticmethod
    def _ordered_uuids(alert):
        """Return the alert's activity UUIDs, de-duplicated, order preserved."""
        seen = set()
        ordered = []
        for uuid in alert.get("activityUUIDs") or []:
            uuid = str(uuid).strip()
            if not uuid or uuid in seen:
                continue
            seen.add(uuid)
            ordered.append(uuid)
        return ordered

    def _activity_delta(self, ordered, state_record):
        """Work out which activity UUIDs of an alert have not been dispatched.

        Armis attaches activities to an existing alert, which bumps the alert's
        update time and brings it back in the next scan carrying its full
        activityUUIDs list. Re-writing that whole list would make the Activity
        function fetch and ingest every activity again.

        Rather than storing the full list per alert, the state row keeps the
        length and the hash of the list as last dispatched. The new list is
        matched against it from both ends, because it is not guaranteed whether
        Armis appends new activities or prepends them. When neither end matches,
        the list was reordered or truncated and the whole list is dispatched
        again, which is safe: it can duplicate, it cannot lose.

        Args:
            ordered (list): the alert's de-duplicated activity UUIDs.
            state_record (dict or None): previously stored dispatch state.

        Returns:
            tuple: (uuids to dispatch, number already dispatched)
        """
        if not state_record:
            return ordered, 0

        try:
            dispatched = int(state_record.get("dispatched_count", 0))
        except (TypeError, ValueError):
            dispatched = 0

        stored_hash = state_record.get("dispatched_hash") or state_record.get(
            "prefix_hash"
        ) or ""

        if not (0 < dispatched <= len(ordered)) or not stored_hash:
            return ordered, 0

        if _hash_uuids(ordered[:dispatched]) == stored_hash:
            # New activities were appended.
            return ordered[dispatched:], dispatched

        if _hash_uuids(ordered[-dispatched:]) == stored_hash:
            # New activities were prepended (newest-first ordering).
            return ordered[: len(ordered) - dispatched], dispatched

        return ordered, 0

    def _store_activity_uuids(
        self, alert, ordered, new_uuids, start_offset, activity_uuids_table
    ):
        """Store the not-yet-dispatched activity UUIDs as pre-chunked rows.

        Row keys carry the absolute offset inside the alert's UUID list rather
        than a per-dispatch counter, so a second dispatch can never overwrite a
        row from the first one that the Activity function has not consumed yet.

        Args:
            alert (dict): alert record.
            ordered (list): the alert's full de-duplicated UUID list.
            new_uuids (list): the subset to dispatch now.
            start_offset (int): position of new_uuids inside ordered.
            activity_uuids_table (ExportsTableStore): destination table.

        Returns:
            dict or None: the state row to persist, or None if nothing changed.
        """
        __method_name = inspect.currentframe().f_code.co_name
        alert_id = str(alert.get("alertId", "")).strip()
        if not alert_id:
            logging.warning(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Alert without alertId, skipping activity UUID storage to "
                    "avoid row key collisions.",
                )
            )
            return None

        if not ordered:
            return None

        if not new_uuids:
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Alert ID {} has no new activity UUIDs ({} already "
                    "dispatched).".format(alert_id, len(ordered)),
                )
            )
            return None

        for start in range(0, len(new_uuids), consts.CHUNK_SIZE):
            chunk = new_uuids[start : start + consts.CHUNK_SIZE]
            # Content-addressed row key: a later dispatch can never overwrite a
            # row the Activity function has not consumed yet, and re-running the
            # same dispatch is idempotent.
            row_key = "{}_{}".format(alert_id, _hash_uuids(chunk)[:16])
            activity_uuids_table.merge(
                ACTIVITY_PARTITION, row_key, {"activity_uuids": ",".join(chunk)}
            )

        logging.info(
            consts.ALERT_LOG_FORMAT.format(
                __method_name,
                "Dispatched {} new activity UUIDs for alert ID {} ({} already "
                "dispatched previously).".format(
                    len(new_uuids), alert_id, start_offset
                ),
            )
        )
        # The alert's own update time, not the connector watermark: the
        # watermark at this point belongs to the previous page, which makes it
        # stale and useless as a purge key.
        seen_at = _to_comparable(alert.get(UPDATE_TIME_FIELD))
        return {
            "dispatched_count": str(len(ordered)),
            "dispatched_hash": _hash_uuids(ordered),
            "last_seen": "" if seen_at is None else repr(seen_at),
        }

    def _dispatch_activity_uuids(
        self, alerts, activity_uuids_table, checkpoint_table
    ):
        """Dispatch the new activity UUIDs for a page of alerts.

        Args:
            alerts (list): alerts about to be ingested.
            activity_uuids_table (ExportsTableStore): destination table for the
                UUID batches the Activity function consumes.
            checkpoint_table (ExportsTableStore): table holding the per-alert
                dispatch state.
        """
        __method_name = inspect.currentframe().f_code.co_name
        with_activities = {}
        for alert in alerts:
            alert_id = str(alert.get("alertId", "")).strip()
            ordered = self._ordered_uuids(alert)
            if alert_id and ordered:
                with_activities[alert_id] = (alert, ordered)

        if not with_activities:
            return

        # One connection for the whole page instead of one per alert.
        states = checkpoint_table.get_many(
            ALERT_STATE_PARTITION, list(with_activities.keys())
        )

        skipped = 0
        for alert_id, (alert, ordered) in with_activities.items():
            new_uuids, already = self._activity_delta(ordered, states.get(alert_id))
            if not new_uuids:
                skipped += len(ordered)
            state = self._store_activity_uuids(
                alert, ordered, new_uuids, already, activity_uuids_table
            )
            if state is not None:
                checkpoint_table.merge(ALERT_STATE_PARTITION, alert_id, state)

        if skipped:
            self.total_activity_uuids_skipped += skipped
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Skipped re-dispatching {} activity UUID(s) already sent to "
                    "the Activity function.".format(skipped),
                )
            )

    # ------------------------------------------------------------------
    # page processing
    # ------------------------------------------------------------------

    def _process_alert_page(
        self,
        alerts,
        next_cursor,
        checkpoint_table: ExportsTableStore,
        activity_uuids_table: ExportsTableStore,
        sentinel_client=None,
    ):
        """Ingest a page of alerts into Sentinel and store their activity UUIDs.

        A page is processed atomically: the timeout is only checked at page
        boundaries, never mid-page, so partial work is never abandoned. The
        checkpoint is written last, after a successful Sentinel ingestion.

        Args:
            alerts (list): alert records for the current page.
            next_cursor: cursor returned by the API for the next page.
            checkpoint_table (ExportsTableStore): checkpoint table.
            activity_uuids_table (ExportsTableStore): activity UUIDs table.
            sentinel_client (LogsIngestionClient, optional): reused client.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            fresh_alerts = self._filter_already_ingested(alerts)

            if not fresh_alerts:
                logging.info(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "No new alerts in this page, advancing cursor only.",
                    )
                )
                self._save_checkpoint(checkpoint_table, next_cursor)
                return

            # Activity UUIDs and their dispatch state are written before the
            # Sentinel upload. A failure after this point replays the alert but
            # finds an empty delta, so activities are never dispatched twice.
            self._dispatch_activity_uuids(
                fresh_alerts, activity_uuids_table, checkpoint_table
            )

            send_data_to_sentinel(
                fresh_alerts, consts.ARMIS_ALERTS_TABLE, client=sentinel_client
            )
            self.total_alerts_posted += len(fresh_alerts)
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Ingested {} alerts to Sentinel.".format(len(fresh_alerts)),
                )
            )

            self._track_pending_watermark(fresh_alerts)
            self._save_checkpoint(checkpoint_table, next_cursor)
        except (ArmisTimeOutException, ArmisDataNotFoundException):
            # Siblings of ArmisException, not subclasses: re-raise before the
            # broad handler below can swallow them.
            raise
        except ArmisException:
            raise
        except Exception as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Error processing alert page: {}.".format(err)
                )
            )
            raise ArmisException("Alert page processing failed") from err

    def fetch_alerts(
        self,
        checkpoint_table,
        activity_uuids_table,
        cursor,
        sentinel_client=None,
    ):
        """Paginate through alerts using the cursor, processing each page.

        Args:
            checkpoint_table (ExportsTableStore): checkpoint table.
            activity_uuids_table (ExportsTableStore): activity UUIDs table.
            cursor: initial cursor from the checkpoint (None starts a new scan).
            sentinel_client (LogsIngestionClient, optional): reused client.
        """
        __method_name = inspect.currentframe().f_code.co_name
        parameter = self._build_parameters()
        pages_processed = 0

        while True:
            if self._timed_out():
                raise ArmisTimeOutException(
                    "Execution budget exhausted after {} pages".format(
                        pages_processed
                    )
                )

            if cursor is not None:
                parameter["cursor"] = cursor
            else:
                parameter.pop("cursor", None)

            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Fetching alerts with cursor: {}.".format(cursor)
                )
            )
            alerts, next_cursor, count = self.get_alert_data(parameter)
            pages_processed += 1

            if not alerts:
                if pages_processed == 1 and cursor is None and self.watermark is None:
                    # Nothing has ever been collected and the very first page is
                    # empty: surface it so the operator can check the AQL.
                    self._save_checkpoint(checkpoint_table, None)
                    raise ArmisDataNotFoundException(
                        "Armis returned no alerts for the configured query"
                    )
                logging.info(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "Empty page received, pagination complete. Cursor reset.",
                    )
                )
                self._promote_watermark()
                self._save_checkpoint(checkpoint_table, None)
                return

            self._process_alert_page(
                alerts,
                next_cursor,
                checkpoint_table,
                activity_uuids_table,
                sentinel_client=sentinel_client,
            )
            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Processed page with {} alerts.".format(count)
                )
            )

            if next_cursor is None:
                self._promote_watermark()
                self._save_checkpoint(checkpoint_table, None)
                logging.info(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "All alerts fetched. Cursor reset in checkpoint.",
                    )
                )
                return

            if next_cursor == cursor:
                # Defensive guard: a stuck cursor would otherwise loop forever.
                logging.warning(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "Armis returned the same cursor '{}' twice. Stopping "
                        "and resetting the cursor to avoid an infinite "
                        "loop.".format(cursor),
                    )
                )
                self._promote_watermark()
                self._save_checkpoint(checkpoint_table, None)
                return

            cursor = next_cursor

    def run(self):
        """Read the checkpoint, initialise tables and drive the fetch loop."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_table = ExportsTableStore(
                connection_string=consts.CONNECTION_STRING,
                table_name=consts.CHECKPOINT_TABLE_NAME,
            )
            checkpoint_table.create()

            activity_uuids_table = ExportsTableStore(
                connection_string=consts.CONNECTION_STRING,
                table_name=consts.ACTIVITY_UUIDS_TABLE_NAME,
            )
            activity_uuids_table.create()

            # One credential and one client for the whole run instead of one
            # per page.
            try:
                sentinel_client = get_sentinel_client()
            except Exception as err:
                logging.error(
                    consts.ALERT_LOG_FORMAT.format(
                        __method_name,
                        "Could not build the Sentinel ingestion client: {}.".format(
                            err
                        ),
                    )
                )
                raise ArmisException("Sentinel client creation failed") from err

            cursor = self._load_checkpoint(checkpoint_table)
            self.fetch_alerts(
                checkpoint_table,
                activity_uuids_table,
                cursor,
                sentinel_client=sentinel_client,
            )

            logging.info(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Run complete. Alerts posted: {}, alerts skipped as "
                    "duplicates: {}, activity UUIDs not re-dispatched: "
                    "{}.".format(
                        self.total_alerts_posted,
                        self.total_alerts_skipped,
                        self.total_activity_uuids_skipped,
                    ),
                )
            )
        except ArmisTimeOutException as err:
            logging.warning(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name,
                    "Execution budget of {}s reached ({}). Stopping cleanly; "
                    "alerts posted this run: {}.".format(
                        consts.FUNCTION_APP_TIMEOUT_SECONDS,
                        err,
                        self.total_alerts_posted,
                    ),
                )
            )
            return
        except ArmisDataNotFoundException:
            raise
        except ArmisException:
            raise
        except Exception as err:
            logging.error(
                consts.ALERT_LOG_FORMAT.format(
                    __method_name, "Error occurred during run: {}.".format(err)
                )
            )
            raise ArmisException("Alert run failed") from err