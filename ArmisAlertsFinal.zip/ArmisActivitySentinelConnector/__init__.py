"""Entry point for the Activity timer-triggered Azure Function."""

import datetime
import logging
import time
import inspect

import azure.functions as func

from SharedCode import consts
from SharedCode.armis_exceptions import ArmisException, ArmisTimeOutException
from .armis_activity import ArmisActivity


def main(mytimer: func.TimerRequest) -> None:
    """Run one Armis activity collection cycle.

    Args:
        mytimer (func.TimerRequest): timer trigger binding.
    """
    __method_name = inspect.currentframe().f_code.co_name

    if mytimer.past_due:
        logging.info(consts.LOG_FORMAT.format(__method_name, "The timer is past due!"))

    utc_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    logging.info(
        consts.LOG_FORMAT.format(
            __method_name, "Activity function triggered at {}.".format(utc_timestamp)
        )
    )

    # Monotonic clock: immune to NTP corrections.
    start_time = time.monotonic()

    try:
        # Construction performs KeyVault and token work and can raise, so it
        # belongs inside the guarded block.
        armis_obj = ArmisActivity(start_time)
        armis_obj.run()
    except ArmisTimeOutException as err:
        # Defensive: run() already handles this, but a clean stop must never be
        # reported as a failed invocation.
        logging.warning(
            consts.LOG_FORMAT.format(
                __method_name,
                "Execution stopped on timeout: {}. Pending rows remain in the "
                "table.".format(err),
            )
        )
    except ArmisException:
        logging.error(
            consts.LOG_FORMAT.format(__method_name, "Activity function failed.")
        )
        # Bare raise keeps the original message and traceback in App Insights.
        raise
    finally:
        utc_timestamp_final = datetime.datetime.now(datetime.timezone.utc).isoformat()
        logging.info(
            consts.LOG_FORMAT.format(
                __method_name, "Execution completed at {}.".format(utc_timestamp_final)
            )
        )
