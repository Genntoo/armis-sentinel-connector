"""Activity collector.

Reads the pre-chunked activity UUID batches written by the Alert function,
fetches the corresponding activity records from Armis, ingests them into
Sentinel and deletes each processed row.

Two de-duplication concerns are handled here:

1. A single Armis activity can be referenced by several alerts, so the same
   UUID legitimately appears in more than one row. Before dispatching work,
   every UUID is claimed by exactly one row for this batch; later rows have it
   stripped out. Without this the activity is ingested once per referencing
   alert.

2. Ingestion is at-least-once. The row is deleted only after a successful
   Sentinel upload, so a failure between the two produces a retry and a
   duplicate. The delete is retried and a failure is logged as an ERROR that
   explicitly predicts the duplicate, so it can be recognised in the logs.

Note on exceptions: ArmisException, ArmisDataNotFoundException and
ArmisTimeOutException are siblings deriving from Exception, not a hierarchy.
Broad handlers re-raise the siblings explicitly.
"""

import logging
import time
import inspect
from concurrent.futures import ThreadPoolExecutor, as_completed

from SharedCode.exports_store import ExportsTableStore
from SharedCode.sentinel import send_data_to_sentinel, get_sentinel_client
from SharedCode.utils import Utils
from SharedCode import consts
from SharedCode.armis_exceptions import ArmisException, ArmisTimeOutException

ACTIVITY_PARTITION = "activityuuids"
# How many UUIDs go into a single Armis query. Kept separate from
# consts.CHUNK_SIZE, which decides how many go into a table row: a row written
# by an older version can hold far more UUIDs than fit in a GET query string,
# and re-chunking those rows is not possible after the fact. Splitting at query
# time handles them without manual intervention.
ACTIVITY_QUERY_BATCH = getattr(consts, "ACTIVITY_QUERY_BATCH", 100)
DELETE_RETRIES = 3
DELETE_RETRY_WAIT = 2


class ArmisActivity(Utils):
    """Fetches Armis activities for pending UUID batches and ingests them."""

    def __init__(self, start_time):
        """Initialize the ArmisActivity object.

        Args:
            start_time (float): value of time.monotonic() captured by the caller
                when the function invocation began.
        """
        super().__init__(log_format=consts.ACTIVITY_LOG_FORMAT)
        self.start_time = start_time
        self.total_activities_posted = 0
        self.total_uuids_deduped = 0
        self.check_environment_var_exist(
            [{"ArmisActivitiesTableName": consts.ARMIS_ACTIVITIES_TABLE}]
        )

    def _timed_out(self):
        """Return True once the function has consumed its execution budget."""
        return (
            time.monotonic() - self.start_time
            >= consts.FUNCTION_APP_TIMEOUT_SECONDS
        )

    # ------------------------------------------------------------------
    # batch preparation
    # ------------------------------------------------------------------

    def _claim_uuids(self, rows):
        """Assign every activity UUID in the batch to exactly one row.

        The same UUID can appear in several rows because several alerts can
        reference the same activity. Processing each row independently would
        ingest that activity once per row. Rows are walked in a deterministic
        order and each UUID is kept only in the first row that carries it.

        Args:
            rows (list): entities read from the activity UUIDs table.

        Returns:
            list: tuples of (row, list of UUIDs this row owns).
        """
        __method_name = inspect.currentframe().f_code.co_name
        seen = set()
        prepared = []
        duplicates = 0

        for row in sorted(
            rows, key=lambda r: (r.get("PartitionKey", ""), r.get("RowKey", ""))
        ):
            raw = row.get("activity_uuids") or ""
            owned = []
            for uuid in raw.split(","):
                uuid = uuid.strip()
                if not uuid:
                    continue
                if uuid in seen:
                    duplicates += 1
                    continue
                seen.add(uuid)
                owned.append(uuid)
            prepared.append((row, owned))

        if duplicates:
            self.total_uuids_deduped = duplicates
            logging.info(
                consts.ACTIVITY_LOG_FORMAT.format(
                    __method_name,
                    "Removed {} duplicate UUID reference(s) across {} row(s); "
                    "{} unique activities will be fetched.".format(
                        duplicates, len(rows), len(seen)
                    ),
                )
            )
        return prepared

    # ------------------------------------------------------------------
    # API access
    # ------------------------------------------------------------------

    def fetch_activities_for_uuids(self, activity_uuids):
        """Fetch activity records from the Armis API for the given UUIDs.

        No logging happens here: this runs in a worker thread where the Azure
        Functions log context is unavailable. Warnings are returned to the
        caller; errors raise ArmisException with a descriptive message.

        Args:
            activity_uuids (list): UUIDs owned by this row.

        Returns:
            tuple: (data, log_entries) where log_entries is a list of
                (level, message) pairs.
        """
        try:
            parameters = {
                "aql": "in:activity UUID:{}".format(",".join(activity_uuids)),
                "from": 0,
                "length": max(len(activity_uuids), 1),
                "fields": ",".join(consts.ACTIVITY_FIELDS),
            }
            results = self.make_rest_call(
                method="GET",
                url=consts.URL + consts.SEARCH_SUFFIX,
                params=parameters,
                headers=self.header,
                retry_401=consts.RETRY_COUNT_401,
                retry_429=consts.RETRY_COUNT_429,
            )

            data_block = results.get("data") if isinstance(results, dict) else None
            if not isinstance(data_block, dict):
                raise ArmisException(
                    "Malformed Armis response: missing 'data' object."
                )

            if "results" not in data_block:
                raise ArmisException(
                    "Malformed Armis response: missing 'results' key."
                )

            data = data_block.get("results") or []
            if not data:
                return [], [
                    ("warning", "Armis returned 0 activities for these UUIDs.")
                ]

            logs = []
            if len(data) < len(activity_uuids):
                logs.append(
                    (
                        "warning",
                        "Requested {} UUIDs but Armis returned {} activities; "
                        "some UUIDs may no longer exist.".format(
                            len(activity_uuids), len(data)
                        ),
                    )
                )

            for item in data:
                item["armis_activity_time"] = item.get("time")
                item["activity_type"] = item.get("type")
                item["activity_title"] = item.get("title")
            return data, logs

        except ArmisException:
            raise
        except Exception as err:
            raise ArmisException(
                "Failed to fetch activities from Armis API: {}.".format(err)
            ) from err

    # ------------------------------------------------------------------
    # row processing
    # ------------------------------------------------------------------

    def _delete_row(self, activity_uuids_table, pk, rk):
        """Delete a processed row, retrying transient storage failures.

        Returns:
            tuple: (succeeded, log_entries)
        """
        last_error = None
        for attempt in range(1, DELETE_RETRIES + 1):
            try:
                activity_uuids_table.delete(pk, rk)
                return True, []
            except Exception as err:
                last_error = err
                if attempt < DELETE_RETRIES:
                    time.sleep(DELETE_RETRY_WAIT)

        return False, [
            (
                "error",
                "Row {}/{} was ingested but could NOT be deleted after {} "
                "attempts ({}). It will be reprocessed on the next run and its "
                "activities WILL be duplicated in Sentinel.".format(
                    pk, rk, DELETE_RETRIES, last_error
                ),
            )
        ]

    def _process_single_row(self, row, owned_uuids, activity_uuids_table, sentinel_client):
        """Fetch, ingest and delete one activity UUID row.

        Logging is avoided here because Azure Functions binds its invocation log
        context to the main thread only. Log entries are returned for emission
        by the caller.

        Args:
            row (dict): table entity.
            owned_uuids (list): UUIDs this row is responsible for after
                cross-row de-duplication.
            activity_uuids_table (ExportsTableStore): source table.
            sentinel_client: shared LogsIngestionClient.

        Returns:
            tuple: (count ingested, log_entries)
        """
        pk = row["PartitionKey"]
        rk = row["RowKey"]
        log_entries = []

        if not owned_uuids:
            # Either an empty row or every UUID was already claimed by another
            # row in this batch. Nothing to fetch, the row is done.
            deleted, delete_logs = self._delete_row(activity_uuids_table, pk, rk)
            log_entries.extend(delete_logs)
            return 0, log_entries

        # Split into query-sized batches. A row can legitimately hold more UUIDs
        # than fit in one request's query string.
        activity_data = []
        batches = [
            owned_uuids[i : i + ACTIVITY_QUERY_BATCH]
            for i in range(0, len(owned_uuids), ACTIVITY_QUERY_BATCH)
        ]
        if len(batches) > 1:
            log_entries.append(
                (
                    "info",
                    "Row {}/{} holds {} UUIDs; querying in {} batches of up to "
                    "{}.".format(pk, rk, len(owned_uuids), len(batches),
                                 ACTIVITY_QUERY_BATCH),
                )
            )
        for batch in batches:
            batch_data, fetch_logs = self.fetch_activities_for_uuids(batch)
            for level, msg in fetch_logs:
                log_entries.append((level, "Row {}/{}: {}".format(pk, rk, msg)))
            activity_data.extend(batch_data)

        if activity_data:
            send_data_to_sentinel(
                activity_data, consts.ARMIS_ACTIVITIES_TABLE, client=sentinel_client
            )
            log_entries.append(
                (
                    "info",
                    "Ingested {} activities from row {}/{}.".format(
                        len(activity_data), pk, rk
                    ),
                )
            )

        deleted, delete_logs = self._delete_row(activity_uuids_table, pk, rk)
        log_entries.extend(delete_logs)
        return (len(activity_data) if activity_data else 0), log_entries

    def process_activity_uuids(self, activity_uuids_table, sentinel_client):
        """Read pending rows and ingest their activities in parallel.

        Failed rows are logged and left in the table so they are retried on the
        next run.

        Args:
            activity_uuids_table (ExportsTableStore): table holding pending
                activity UUID batches.
            sentinel_client: shared LogsIngestionClient.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            # Scoped to the partition the Alert function writes into. A
            # list_all() here would consume and delete anything else that
            # ever lands in this table.
            rows = list(activity_uuids_table.query_by_partition_key(ACTIVITY_PARTITION))
            if not rows:
                logging.info(
                    consts.ACTIVITY_LOG_FORMAT.format(
                        __method_name, "No pending activity UUID rows to process."
                    )
                )
                return

            prepared = self._claim_uuids(rows)

            logging.info(
                consts.ACTIVITY_LOG_FORMAT.format(
                    __method_name,
                    "Processing {} pending row(s) with {} worker(s).".format(
                        len(prepared), consts.ACTIVITY_WORKER_COUNT
                    ),
                )
            )
            failed = 0
            timed_out = False
            submitted = 0

            with ThreadPoolExecutor(
                max_workers=consts.ACTIVITY_WORKER_COUNT
            ) as executor:
                futures = {}
                for row, owned in prepared:
                    if self._timed_out():
                        timed_out = True
                        break
                    futures[
                        executor.submit(
                            self._process_single_row,
                            row,
                            owned,
                            activity_uuids_table,
                            sentinel_client,
                        )
                    ] = row
                submitted = len(futures)

                for future in as_completed(futures):
                    row = futures[future]
                    pk, rk = row["PartitionKey"], row["RowKey"]
                    try:
                        count, log_entries = future.result()
                        for level, msg in log_entries:
                            getattr(logging, level)(
                                self.log_format.format("_process_single_row", msg)
                            )
                        self.total_activities_posted += count
                    except ArmisException as exc:
                        logging.error(
                            consts.ACTIVITY_LOG_FORMAT.format(
                                __method_name,
                                "Row {}/{} failed ({}); will be retried on next "
                                "run.".format(pk, rk, exc or "unknown error"),
                            ),
                            exc_info=True,
                        )
                        failed += 1
                    except Exception as exc:
                        logging.error(
                            consts.ACTIVITY_LOG_FORMAT.format(
                                __method_name,
                                "Row {}/{} raised unexpected error ({}); will be "
                                "retried on next run.".format(pk, rk, exc),
                            ),
                            exc_info=True,
                        )
                        failed += 1

            if failed:
                if submitted and failed == submitted:
                    logging.error(
                        consts.ACTIVITY_LOG_FORMAT.format(
                            __method_name,
                            "All {}/{} row(s) failed. Likely a systemic issue "
                            "(credentials, connectivity or API contract).".format(
                                failed, submitted
                            ),
                        )
                    )
                    raise ArmisException(
                        "All {} rows failed in this run".format(failed)
                    )
                logging.warning(
                    consts.ACTIVITY_LOG_FORMAT.format(
                        __method_name,
                        "{}/{} row(s) failed. They remain in the table for "
                        "retry.".format(failed, submitted),
                    )
                )

            if timed_out:
                raise ArmisTimeOutException(
                    "Execution budget exhausted after submitting {} of {} "
                    "rows".format(submitted, len(prepared))
                )

        except ArmisTimeOutException:
            raise
        except ArmisException:
            raise
        except Exception as err:
            logging.error(
                consts.ACTIVITY_LOG_FORMAT.format(
                    __method_name, "Error processing activity UUIDs: {}.".format(err)
                )
            )
            raise ArmisException("Activity UUID processing failed") from err

    def run(self):
        """Set up the table, build a shared Sentinel client and process rows."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            activity_uuids_table = ExportsTableStore(
                connection_string=consts.CONNECTION_STRING,
                table_name=consts.ACTIVITY_UUIDS_TABLE_NAME,
            )
            activity_uuids_table.create()

            try:
                sentinel_client = get_sentinel_client()
            except Exception as err:
                logging.error(
                    consts.ACTIVITY_LOG_FORMAT.format(
                        __method_name,
                        "Could not build the Sentinel ingestion client: {}.".format(
                            err
                        ),
                    )
                )
                raise ArmisException("Sentinel client creation failed") from err

            self.process_activity_uuids(activity_uuids_table, sentinel_client)
            logging.info(
                consts.ACTIVITY_LOG_FORMAT.format(
                    __method_name,
                    "Run complete. Activities posted: {}, duplicate UUID "
                    "references skipped: {}.".format(
                        self.total_activities_posted, self.total_uuids_deduped
                    ),
                )
            )
        except ArmisTimeOutException as err:
            logging.warning(
                consts.ACTIVITY_LOG_FORMAT.format(
                    __method_name,
                    "Execution budget of {}s reached ({}). Remaining rows stay "
                    "in the table; activities posted this run: {}.".format(
                        consts.FUNCTION_APP_TIMEOUT_SECONDS,
                        err,
                        self.total_activities_posted,
                    ),
                )
            )
            return
        except ArmisException:
            raise
        except Exception as err:
            logging.error(
                consts.ACTIVITY_LOG_FORMAT.format(
                    __method_name, "Error occurred during run: {}.".format(err)
                )
            )
            raise ArmisException("Activity run failed") from err