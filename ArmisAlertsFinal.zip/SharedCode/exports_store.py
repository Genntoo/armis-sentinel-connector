import logging

from azure.data.tables import TableClient, UpdateMode
from azure.core.exceptions import (
    ResourceNotFoundError,
    ResourceExistsError,
    HttpResponseError,
)


class ExportsTableStore:

    def __init__(self, connection_string, table_name):
        self.connection_string = connection_string
        self.table_name = table_name

    def create(self):
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            try:
                table_client.create_table()
                logging.info("Checkpoint Table created")
            except ResourceExistsError:
                logging.warning("Checkpoint Table already exists")

    def post(self, pk: str, rk: str, data: dict = None):
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            entity_template = {
                "PartitionKey": pk,
                "RowKey": rk,
            }
            if data is not None:
                entity_template.update(data)
            try:
                table_client.create_entity(entity_template)
            except Exception as e:
                logging.warning("could not post entity to table")
                logging.warning(e)
                raise e

    def get(self, pk: str, rk: str):
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            try:
                logging.info(
                    "looking for {} - {} on table {}".format(pk, rk, self.table_name)
                )
                return table_client.get_entity(pk, rk)
            except ResourceNotFoundError:
                return None

    def upsert(self, pk: str, rk: str, data: dict = None):
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            logging.info(
                "upserting {} - {} on table {}".format(pk, rk, self.table_name)
            )
            entity_template = {
                "PartitionKey": pk,
                "RowKey": rk,
            }
            if data is not None:
                entity_template.update(data)
            return table_client.upsert_entity(
                mode=UpdateMode.REPLACE, entity=entity_template
            )

    def update_if_found(self, pk: str, rk: str, data: dict = None):
        if self.get(pk, rk) is not None:
            self.merge(pk, rk, data)

    def query_by_partition_key(self, pk):
        table_client = TableClient.from_connection_string(
            self.connection_string, self.table_name
        )
        parameters = {"key": pk}
        name_filter = "PartitionKey eq @key"
        try:
            return table_client.query_entities(name_filter, parameters=parameters)
        except HttpResponseError as e:
            print(e.message)
            return []

    def batch(self, operations):
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            return table_client.submit_transaction(operations=operations)

    def list_all(self):
        table_client = TableClient.from_connection_string(
            self.connection_string, self.table_name
        )
        return table_client.list_entities()

    def get_many(self, pk: str, row_keys):
        """Fetch several entities from one partition over a single connection.

        Every other method here opens its own TableClient, which means a TLS
        handshake per entity. Reading N rows one by one that way is slow enough
        to matter inside the function's execution budget.

        Args:
            pk (str): partition key.
            row_keys (iterable): row keys to look up.

        Returns:
            dict: row key -> entity, for the keys that exist.
        """
        found = {}
        keys = [rk for rk in row_keys if rk]
        if not keys:
            return found
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            for rk in keys:
                try:
                    found[rk] = table_client.get_entity(pk, rk)
                except ResourceNotFoundError:
                    continue
        return found

    def merge(self, pk: str, rk: str, data: dict = None):
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            # logging.info(
            #     "upserting {} - {} on table {}".format(pk, rk, self.table_name)
            # )
            entity_template = {
                "PartitionKey": pk,
                "RowKey": rk,
            }
            if data is not None:
                entity_template.update(data)
            return table_client.upsert_entity(
                mode=UpdateMode.MERGE, entity=entity_template
            )

    def delete(self, pk: str, rk: str):
        with TableClient.from_connection_string(
            self.connection_string, self.table_name
        ) as table_client:
            try:
                table_client.delete_entity(partition_key=pk, row_key=rk)
                logging.info(
                    "Deleted entity {}/{} from table {}.".format(
                        pk, rk, self.table_name
                    )
                )
            except ResourceNotFoundError:
                logging.warning(
                    "Entity {}/{} not found in table {}.".format(
                        pk, rk, self.table_name
                    )
                )