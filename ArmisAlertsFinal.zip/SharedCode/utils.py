"""Utility module."""

import inspect
import logging
import threading
import time
from SharedCode.armis_exceptions import ArmisException
import requests
from . import consts
from .keyvault_secrets_management import KeyVaultSecretManager


class Utils:
    """Utils Class."""

    # Fallback so that Utils() without an explicit format does not blow up with
    # AttributeError on the first line of __init__.
    log_format = consts.LOG_FORMAT

    def __init__(self, log_format=None) -> None:
        """Init Function."""
        self.log_format = log_format if log_format is not None else Utils.log_format
        self.retry_count = 0
        self.header = {}
        # The Activity function runs ACTIVITY_WORKER_COUNT threads that share
        # self.header. Without this lock a token expiry makes every worker
        # refresh the token at the same time, each overwriting the KeyVault
        # secret and invalidating the token the others just obtained.
        self._token_lock = threading.RLock()
        self.check_environment_var_exist(
            [
                {"ArmisURL": consts.URL},
                {"ArmisSecretKey": consts.API_KEY},
                {"AzureWebJobsStorage": consts.CONNECTION_STRING},
            ]
        )
        self._secret_key = consts.API_KEY
        self.keyvault_obj = KeyVaultSecretManager()
        self.access_token_key = "armis-access-token"
        properties_list = self.keyvault_obj.get_properties_list_of_secrets()
        if self.access_token_key in properties_list:
            self.access_token = self.keyvault_obj.get_keyvault_secret(self.access_token_key)
            self.header.update({"Authorization": self.access_token})
        else:
            self.get_access_token()

    def check_environment_var_exist(self, environment_var):
        """Check the existence of required environment variables.

        Args:
            environment_var(list) : variables to check for existence
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            logging.info(self.log_format.format(__method_name, "Validating Environment Variables."))
            missing_required_field = False
            for var in environment_var:
                key, val = next(iter(var.items()))
                if not val:
                    missing_required_field = True
                    logging.error(
                        self.log_format.format(__method_name, "Environment variable {} is not set.".format(key))
                    )
            if missing_required_field:
                logging.error(self.log_format.format(__method_name, "Environment Variables validation failed."))
                raise ArmisException()
            logging.info(self.log_format.format(__method_name, "Environment Variables validation Success."))
        except ArmisException:
            raise ArmisException()
        except Exception as err:
            logging.error(
                self.log_format.format(__method_name, "Error while checking environment variables: {}".format(err))
            )
            raise ArmisException()

    def compare_access_token(self, failed_token=None):
        """Refresh the access token, at most once per actual expiry.

        Args:
            failed_token (str, optional): the token this caller was using when
                it received the 401. When another thread has already replaced it
                the refresh is skipped, which is what keeps concurrent workers
                from invalidating each other's freshly issued tokens.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            with self._token_lock:
                current_token = self.header.get("Authorization")
                if failed_token is not None and failed_token != current_token:
                    logging.info(self.log_format.format(
                        __method_name,
                        "Token already refreshed by another worker. Reusing it."
                    ))
                    return

                keyvault_access_token = self.keyvault_obj.get_keyvault_secret(self.access_token_key)
                if keyvault_access_token and keyvault_access_token != current_token:
                    logging.info(self.log_format.format(
                        __method_name, "KeyVault Access Token Updated. Updating Header Value."
                    ))
                    self.header.update({"Authorization": keyvault_access_token})
                    return

                logging.info(self.log_format.format(
                    __method_name, "KeyVault Access Token Invalid. Generating New Token."
                ))
                self.get_access_token()
        except ArmisException:
            raise
        except Exception as err:
            logging.error(
                self.log_format.format(
                    __method_name,
                    "Unexpected error : {}.".format(err),
                )
            )
            raise ArmisException("Access token comparison failed") from err

    def make_rest_call(self, method, url, params=None, headers=None, data=None,
                       retry_401=0, retry_429=0, retry_connection_error=0):
        """Make a rest call with configurable retries for 401, 429, and connection errors.

        Args:
            url (str): The URL to make the call to.
            method (str): The HTTP method to use for the call.
            params (dict, optional): The parameters to pass in the call (default is None).
            headers (dict, optional): The headers to pass in the call (default is None).
            data (dict, optional): The body of the request (default is None).
            retry_401 (int): Number of retries on 401 Unauthorized (default is 0).
            retry_429 (int): Number of retries on 429 Too Many Requests (default is 0).
            retry_connection_error (int): Number of retries on HTTP connection loss (default is 0).

        Returns:
            dict: The JSON response if the call is successful.
        """
        __method_name = inspect.currentframe().f_code.co_name
        attempts_401 = 0
        attempts_429 = 0
        attempts_conn = 0
        # The headers argument used to be accepted and silently ignored.
        request_headers = headers if headers is not None else self.header
        try:
            while True:
                # Captured per attempt so a 401 refresh knows which token failed.
                token_used = request_headers.get("Authorization")
                try:
                    response = requests.request(
                        method, url, headers=request_headers, params=params, data=data,
                        timeout=consts.REQUEST_TIMEOUT,
                    )
                except requests.ConnectionError as err:
                    if attempts_conn < retry_connection_error:
                        attempts_conn += 1
                        logging.warning(
                            self.log_format.format(
                                __method_name,
                                "HTTP connection lost. Retrying ({}/{}) in {}s: {}.".format(
                                    attempts_conn, retry_connection_error,
                                    consts.RETRY_WAIT_CONNECTION_ERROR, err,
                                ),
                            )
                        )
                        time.sleep(consts.RETRY_WAIT_CONNECTION_ERROR)
                        continue
                    logging.error(
                        self.log_format.format(
                            __method_name,
                            "Connection error after {} retries: {}.".format(attempts_conn, err),
                        )
                    )
                    raise ArmisException()

                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 400:
                    logging.error(
                        self.log_format.format(
                            __method_name,
                            "Bad Request = {}, Status code : {}.".format(
                                response.text, response.status_code
                            ),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 401:
                    if attempts_401 < retry_401:
                        attempts_401 += 1
                        self.retry_count += 1
                        logging.warning(
                            self.log_format.format(
                                __method_name,
                                "Unauthorized (401). Refreshing token and retrying ({}/{})...".format(
                                    attempts_401, retry_401
                                ),
                            )
                        )
                        self.compare_access_token(failed_token=token_used)
                        continue
                    logging.error(
                        self.log_format.format(
                            __method_name,
                            "Unauthorized (401). Max retries ({}) exceeded.".format(retry_401),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 429:
                    if attempts_429 < retry_429:
                        attempts_429 += 1
                        wait = int(response.headers.get("Retry-After", consts.RETRY_WAIT_429))
                        logging.warning(
                            self.log_format.format(
                                __method_name,
                                "Rate limited (429). Retrying ({}/{}) after {}s...".format(
                                    attempts_429, retry_429, wait
                                ),
                            )
                        )
                        time.sleep(wait)
                        continue
                    logging.error(
                        self.log_format.format(
                            __method_name,
                            "Rate limited (429). Max retries ({}) exceeded.".format(retry_429),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 500:
                    logging.error(
                        self.log_format.format(
                            __method_name,
                            "Internal Server Error, Status code : {}.".format(response.status_code),
                        )
                    )
                    raise ArmisException()
                elif response.status_code == 502:
                    logging.error(
                        self.log_format.format(
                            __method_name,
                            "Bad Gateway, Status code : {}.".format(response.status_code),
                        )
                    )
                    raise ArmisException()
                else:
                    logging.error(
                        self.log_format.format(
                            __method_name,
                            "Unexpected Error = {}, Status code : {}.".format(
                                response.text, response.status_code
                            ),
                        )
                    )
                    raise ArmisException()
        except ArmisException:
            raise ArmisException()
        except requests.HTTPError as err:
            logging.error(
                self.log_format.format(
                    __method_name,
                    "HTTP error : {}.".format(err),
                )
            )
            raise ArmisException()
        except requests.Timeout as err:
            logging.error(
                self.log_format.format(
                    __method_name,
                    "Timeout error : {}.".format(err),
                )
            )
            raise ArmisException()
        except requests.exceptions.InvalidURL as err:
            logging.error(
                self.log_format.format(
                    __method_name,
                    "Invalid URL error : {}.".format(err),
                )
            )
            raise ArmisException()
        except Exception as err:
            logging.error(
                self.log_format.format(
                    __method_name,
                    "Unexpected error : {}.".format(err),
                )
            )
            raise ArmisException()

    def get_formatted_time(self, alert_time):
        """Format alert time.

        Args:
            alert_time (str): time to format

        Returns:
            str: formatted time
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if len(alert_time) != 19:
                if len(alert_time) == 10:
                    alert_time += "T00:00:00"
                    logging.info(
                        self.log_format.format(__method_name, "'T:00:00:00' added as only date is available.")
                    )
                else:
                    splited_time = alert_time.split("T")
                    if len(splited_time[1]) == 5:
                        splited_time[1] += ":00"
                        logging.info(self.log_format.format(__method_name, "':00' added as seconds not available."))
                    elif len(splited_time[1]) == 2:
                        splited_time[1] += ":00:00"
                        logging.info(
                            self.log_format.format(__method_name, "':00:00' added as only hour is available.")
                        )
                    alert_time = "T".join(splited_time)
            return alert_time
        except KeyError as err:
            logging.error(self.log_format.format(__method_name, "Key error : {}.".format(err)))
            raise ArmisException()
        except Exception as err:
            logging.error(
                self.log_format.format(__method_name, "Error while formatting time : {}.".format(err))
            )
            raise ArmisException()

    def get_access_token(self):
        """Fetch the access token from Armis API and store it in the header and keyvault."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            body = {"secret_key": self._secret_key}
            logging.info(self.log_format.format(__method_name, "Getting access token."))
            response = self.make_rest_call(method="POST", url=consts.URL + consts.ACCESS_TOKEN_SUFFIX, data=body)
            access_token = response.get("data", {}).get("access_token")
            self.header.update({"Authorization": access_token})
            self.keyvault_obj.set_keyvault_secret(self.access_token_key, access_token)
            logging.info(self.log_format.format(__method_name, "Generated access token Successfully."))
        except KeyError as err:
            logging.error(self.log_format.format(__method_name, "Key error : {}.".format(err)))
            raise ArmisException()
        except ArmisException:
            raise ArmisException()
        except Exception as err:
            logging.error(
                self.log_format.format(__method_name, "Error while generating the access token : {}.".format(err))
            )
            raise ArmisException()