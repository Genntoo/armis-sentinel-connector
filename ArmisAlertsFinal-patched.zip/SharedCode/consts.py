"""Module for constants."""

import os

# Armis API constants
API_KEY = os.environ.get("ArmisSecretKey", "")
URL = os.environ.get("ArmisURL", "")
ACCESS_TOKEN_SUFFIX = "/access_token/"
SEARCH_SUFFIX = "/search/"
ACTIVITY_FIELDS = ["title", "type", "time", "site", "sensor", "protocol", "content", "activityUUID"]
ALERT_FIELDS = [
    "alertId",
    "type",
    "title",
    "description",
    "severity",
    "time",
    "status",
    "deviceIds",
    "activityUUIDs",
]
RETRY_COUNT_401 = 3
RETRY_COUNT_429 = 3
RETRY_WAIT_429 = 60  # seconds; overridden by Retry-After response header when present
RETRY_WAIT_CONNECTION_ERROR = 5  # seconds between connection-error retries
SEVERITY = os.environ.get("Severity", "Low")
SEVERITIES = ["Low", "Medium", "High", "Critical"]

# Azure Storage / Sentinel constants
CONNECTION_STRING = os.environ.get("AzureWebJobsStorage", "")
ARMIS_ALERTS_TABLE = os.environ.get("ArmisAlertsTableName", "")
ARMIS_ACTIVITIES_TABLE = os.environ.get("ArmisActivitiesTableName", "")
WORKSPACE_ID = os.environ.get("WorkspaceID", "")
WORKSPACE_KEY = os.environ.get("WorkspaceKey", "")
KEYVAULT_NAME = os.environ.get("KeyVaultName", "")
FILE_SHARE = os.environ.get("FileShareName", "")
ALERTS_CHUNK = 100
CHUNK_SIZE = 500
ACTIVITY_WORKER_COUNT = 5
LOG_FORMAT = "Armis Alerts Activities Connector: (method = {}) : {}"
ALERT_LOG_FORMAT = "Armis Alert Connector: (method = {}) : {}"
ACTIVITY_LOG_FORMAT = "Armis Activity Connector: (method = {}) : {}"
REQUEST_TIMEOUT = 300
CHECKPOINT_TABLE_NAME = "ArmisAlertActivityCheckpoint"
ACTIVITY_UUIDS_TABLE_NAME = "ArmisActivityUUIDs"
FUNCTION_APP_TIMEOUT_SECONDS = 570

# DCR / Data Collection constants
DCR_RULE_ID = os.environ.get("DCR_RULE_ID")
AZURE_DATA_COLLECTION_ENDPOINT = os.environ.get("AZURE_DATA_COLLECTION_ENDPOINT")
SCOPE = os.environ.get("SCOPE")
AZURE_CLIENT_ID = os.environ.get("AZURE_CLIENT_ID")
AZURE_CLIENT_SECRET = os.environ.get("AZURE_CLIENT_SECRET")
AZURE_TENANT_ID = os.environ.get("AZURE_TENANT_ID")
